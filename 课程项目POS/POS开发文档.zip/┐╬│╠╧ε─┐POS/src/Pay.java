

public class Pay {
    private float cash;

   public Pay(float cash) {
        this.cash = cash;
    }
    public float getCash(){
        return cash;
    }
}
