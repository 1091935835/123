﻿#include"basic.h"
#include <iostream>
using namespace std;
extern LStack<double> OPND;
extern LStack<char> OPTR;

void start();
void testRead();

int main()
{
	printIntroduction();
	//testRead();
	start();
	return 0;
}

//123-4*5+6=
void start() {
	getInput();

	//prior_char 表示当前处理字符的前一个字符，如为数，则其值'0'
	char prior_char, ch, OPTR_top;
	double operand, tempDouble, tempR, tempA, tempB;

	prior_char = '=';
	OPTR.push(prior_char);
	GetNextChar(ch); 
	OPTR_top = OPTR.topValue();
	while (OPTR_top != '=' || ch != '=') {
		// 当前字符为数字
		if (isDigit(ch) || ch == '.') {
			operand = readOperand();
			OPND.push(operand);       
			prior_char = '0';  
			GetNextChar(ch);
		}
		else if (!IsOperator(ch)) {
			cout << "表括达式有错!" << endl;
		}
		// 当前字符为运算符
		else {
			//第一个数字带有符号的情况
			if ((prior_char == '=' || prior_char == '(') &&
				(ch == '+' || ch == '-')) {
				tempDouble = 0;
				OPND.push(tempDouble);
				operand = readOperand();
				OPND.push(operand);
				prior_char = '0';
				GetNextChar(ch);
			}
			//栈内优先级低于栈外优先级
			if (isp(OPTR_top) < osp(ch)) {
				OPTR.push(ch);
				prior_char = ch;
				GetNextChar(ch);

			}
			//栈内优先级高于栈外优先级
			else if (isp(OPTR_top) > osp(ch)) {
				Get2Operands(OPND, tempA, tempB);
				OPTR_top = OPTR.pop();
				cal(OPTR_top, tempA, tempB, tempR);
				OPND.push(tempR);


			}
			//栈内优先级等于栈外优先级
			else {
				OPTR.pop();
				GetNextChar(ch);

			}
		}
		OPTR_top = OPTR.topValue();
		if (!OPTR_top) { cout << "表括达式有错!" << endl;  return; }
	}

	//  输出答案
	if (OPND.length() != 1) {
		cout << "表括达式有错!" << endl;  return;
	}
	else {
		cout << "答案是:" << OPND.pop() << endl;
	}

}

// 测试读取double数据 done
void testRead() {
	getInput();
	char ch;
	GetNextChar(ch);
	cout << readOperand() << endl;
	GetNextChar(ch);
	GetNextChar(ch);
	cout << readOperand() << endl;
}